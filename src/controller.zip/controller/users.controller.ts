// src/controller/users.controller.ts
import { Request, Response } from "express";
import { pool } from "../database";
import { RowDataPacket } from "mysql2";

export const listUsers = async (_req: Request, res: Response): Promise<Response> => {
  try {
    const [users] = await pool.query<RowDataPacket[]>(
      `SELECT 
         id, 
         username, 
         email, 
         full_name, 
         phone_number, 
         role_id, 
         id_academia,       -- ahora incluimos id_academia
         is_active, 
         created_at, 
         updated_at 
       FROM users`
    );
    return res.status(200).json(users);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener usuarios" });
  }
};
