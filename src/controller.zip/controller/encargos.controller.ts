// src/controller/encargos.controller.ts
import { Request, Response } from "express";
import { pool } from "../database";
import { RowDataPacket, OkPacket, ResultSetHeader } from "mysql2";

// Crear un nuevo encargo o subencargo
export const createEncargo = async (req: Request, res: Response): Promise<Response> => {
  try {
    const {
      nombre_encargo,
      descripcion_encargo,
      user_id,
      numero_preguntas_encargo,
      encargo_padre_id,
      id_tema,
      id_asignatura,
      id_academia
    }: {
      nombre_encargo: string;
      descripcion_encargo?: string;
      user_id: number;
      numero_preguntas_encargo?: number;
      encargo_padre_id?: number;
      id_tema?: number;
      id_asignatura?: number;
      id_academia?: number;
    } = req.body;

    const [result] = await pool.query<OkPacket>(
      `INSERT INTO encargos
         (nombre_encargo, descripcion_encargo, user_id,
          numero_preguntas_encargo, encargo_padre_id,
          id_tema, id_asignatura, id_academia)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        nombre_encargo,
        descripcion_encargo || null,
        user_id,
        numero_preguntas_encargo || 0,
        encargo_padre_id || null,
        id_tema || null,
        id_asignatura || null,
        id_academia || null
      ]
    );

    return res.status(201).json({ id: result.insertId });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al crear encargo" });
  }
};

// Listar todos los encargos
export const getEncargos = async (_req: Request, res: Response): Promise<Response> => {
  const sql = `
    SELECT 
      e.*,
      IFNULL((
        SELECT COUNT(*) 
        FROM preguntas p 
        WHERE p.id_encargo = e.id_encargo
      ), 0) AS preguntas_actuales
    FROM encargos e
    ORDER BY e.id_encargo
  `;
  try {
    const [rows] = await pool.query<RowDataPacket[]>(sql);
    return res.json(rows);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener encargos" });
  }
};

// Obtener encargos de un usuario, incluyendo contador de preguntas actuales
export const getEncargosByUser = async (req: Request, res: Response): Promise<Response> => {
  const userId = Number(req.params.userId);
  if (isNaN(userId)) return res.status(400).json({ message: "userId inválido" });

  const sql = `
    SELECT
      e.*,
      CASE
        -- Si tiene hijos, sumar sus preguntas
        WHEN EXISTS (
          SELECT 1
          FROM encargos c2
          WHERE c2.encargo_padre_id = e.id_encargo
        )
        THEN (
          SELECT COALESCE(SUM(cnt), 0) FROM (
            SELECT COUNT(*) AS cnt
            FROM preguntas p
            WHERE p.id_encargo IN (
              SELECT id_encargo
              FROM encargos c3
              WHERE c3.encargo_padre_id = e.id_encargo
            )
            GROUP BY p.id_encargo
          ) AS sub
        )
        -- Si no tiene hijos (o es hijo), cuenta sus propias preguntas
        ELSE (
          SELECT COUNT(*)
          FROM preguntas p
          WHERE p.id_encargo = e.id_encargo
        )
      END AS preguntas_actuales
    FROM encargos e
    WHERE e.user_id = ?
    ORDER BY e.id_encargo
  `;

  try {
    const [rows] = await pool.query<RowDataPacket[]>(sql, [userId]);
    return res.json(rows);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al obtener encargos del usuario" });
  }
};

// Obtener encargo por ID
export const getEncargoById = async (req: Request, res: Response): Promise<Response> => {
  const id = Number(req.params.id);
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM encargos WHERE id_encargo = ?",
      [id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: "Encargo no encontrado" });
    }
    return res.json(rows[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al buscar encargo" });
  }
};

// Listar sub-encargos de un padre
export const getSubencargos = async (req: Request, res: Response): Promise<Response> => {
  const parentId = Number(req.params.id);
  if (isNaN(parentId)) return res.status(400).json({ message: "ID de padre inválido" });
  try {
    const [rows] = await pool.query<RowDataPacket[]>(
      "SELECT * FROM encargos WHERE encargo_padre_id = ?",
      [parentId]
    );
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Error al obtener sub-encargos" });
  }
};

// Actualizar un encargo
export const updateEncargo = async (req: Request, res: Response): Promise<Response> => {
  const id = Number(req.params.id);
  try {
    const {
      nombre_encargo,
      descripcion_encargo,
      user_id,
      numero_preguntas_encargo,
      encargo_padre_id,
      id_tema,
      id_asignatura,
      id_academia
    }: {
      nombre_encargo: string;
      descripcion_encargo?: string;
      user_id: number;
      numero_preguntas_encargo?: number;
      encargo_padre_id?: number;
      id_tema?: number;
      id_asignatura?: number;
      id_academia?: number;
    } = req.body;

    const [result] = await pool.query<ResultSetHeader>(
      `UPDATE encargos SET
         nombre_encargo = ?,
         descripcion_encargo = ?,
         user_id = ?,
         numero_preguntas_encargo = ?,
         encargo_padre_id = ?,
         id_tema = ?,
         id_asignatura = ?,
         id_academia = ?
       WHERE id_encargo = ?`,
      [
        nombre_encargo,
        descripcion_encargo || null,
        user_id,
        numero_preguntas_encargo || 0,
        encargo_padre_id || null,
        id_tema || null,
        id_asignatura || null,
        id_academia || null,
        id
      ]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Encargo no encontrado" });
    }
    return res.json({ message: "Encargo actualizado" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al actualizar encargo" });
  }
};

// Eliminar un encargo
export const deleteEncargo = async (req: Request, res: Response): Promise<Response> => {
  const id = Number(req.params.id);
  try {
    const [result] = await pool.query<ResultSetHeader>(
      "DELETE FROM encargos WHERE id_encargo = ?",
      [id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Encargo no encontrado" });
    }
    return res.json({ message: "Encargo eliminado" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al eliminar encargo" });
  }
};

// Cambiar sólo el estado de un encargo
export const patchEstadoEncargo = async (req: Request, res: Response): Promise<Response> => {
  const id = Number(req.params.id);
  const { estado_encargo }: { estado_encargo: boolean } = req.body;
  try {
    const [result] = await pool.query<ResultSetHeader>(
      "UPDATE encargos SET estado_encargo = ? WHERE id_encargo = ?",
      [(estado_encargo ? 1 : 0), id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Encargo no encontrado" });
    }
    return res.json({ message: "Estado actualizado correctamente" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Error al actualizar estado del encargo" });
  }
};
